import { useState, useEffect } from "react";
// import OrderList from './OrderList';

function Menu() {
    const [products, setProducts] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('breakfast');
    const [orderedProducts, setOrderedProducts] = useState([]);


    const addToOrder = (product) => {
        setOrderedProducts([...orderedProducts, product]);
    };
    

    useEffect(() => {
        async function fetchData() {
            const res = await fetch("http://localhost/react_php_pp5/backend/index.php");
            const result = await res.json();
            setProducts(result.data);
        }
        fetchData();
    }, []);

    const handleChangeCategory = (category) => {
        setSelectedCategory(category);
    };

    return (
        <div id="menu-section" className="container-xxl py-5">
            <div className="container">
                <div className="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h5 className="section-title ff-secondary text-center text-primary fw-normal">Food Menu</h5>
                    <h1 className="mb-5">Specially For You</h1>
                </div>
                <div className="tab-class text-center wow fadeInUp" data-wow-delay="0.1s">
                    <ul className="nav nav-pills d-inline-flex justify-content-center border-bottom mb-5">
                        {[
                            { name: 'Awesome', category: 'breakfast', icon: 'fa-coffee' },
                            { name: 'Special', category: 'lunch', icon: 'fa-hamburger' },
                            { name: 'Lovely', category: 'dinner', icon: 'fa-utensils' },
                            { name: 'Satisfying', category: 'pastries', icon: 'fa-hamburger' },
                        ].map((item, index) => (
                            <li className="nav-item" key={index}>
                                <button
                                    className={`nav-link d-flex align-items-center text-start mx-3 ${item.category === selectedCategory ? 'active' : ''}`}
                                    data-bs-toggle="pill"
                                    onClick={() => handleChangeCategory(item.category)}
                                >
                                    <i className={`fa ${item.icon} fa-2x text-primary`}></i>
                                    <div className="ps-3">
                                        <small className="text-body">{item.name}</small>
                                        <h6 className="mt-n1 mb-0">{item.category === 'pastries' ? 'Pastries | Desserts' : item.category}</h6>
                                    </div>
                                </button>
                            </li>
                        ))}
                    </ul>
                    <div id="menu"></div>
                    <div className="tab-content">
                        {['breakfast', 'lunch', 'dinner', 'pastries'].map((category, index) => (
                            <div id={`tab-${index + 1}`} className={`tab-pane fade show p-0 ${category === selectedCategory ? 'active' : ''}`} key={index}>
                                <div id={`container-${index + 1}`} className="row g-4">
                                    {products
                                        .filter((product) => product.category_name.toLowerCase() === category)
                                        .map((product, productIndex) => (
                                            <div className="col-lg-6" key={productIndex}>
                                                <div className="d-flex align-items-start">
                                                    <img
                                                        className="flex-shrink-0 img-fluid rounded-3 border border-5"
                                                        src={`/image/menu/${category}/${product.img_path}`}
                                                        alt={product.product_name}
                                                        style={{ width: '250px', height: '250px' }}
                                                    />
                                                    <div className="w-100 d-flex flex-column text-start ps-4">
                                                        <h6 className="d-flex justify-content-between border-bottom pb-2">
                                                            <span>{product.product_name}</span>
                                                        </h6>
                                                        <div>
                                                            <span className="text-primary fw-bold">{product.price} php <button onClick={addToOrder} className='btn btn-warning btn-sm text-lowercase rounded-pill' style={{ height: '30px', width: 'auto' }} href='' >Add to Orders</button></span>
                                                        </div>
                                                        <small className="fst-italic">{product.description}</small>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Menu;
