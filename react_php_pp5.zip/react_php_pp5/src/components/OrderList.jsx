import React, { useState } from 'react';

function OrderList({ orderedProducts }) {
    return (
<div class="container-fluid row py-0 px-0 wow fadeInUp" data-wow-delay="0.1s">
                <div class="row-col-md-6 bg-dark h-auto w-50">
                    <div class="px-5 wow fadeInUp" data-wow-delay="0.2s" style={{paddingTop: '80px', paddingBottom: '80px'}}>
                        <h5 class="section-title ff-secondary text-start text-primary fw-normal">Reservation</h5>
                        <h1 class="text-white mb-4">Book Now!</h1>
                        <form action="POST">
                            <div class="row g-3 py-4">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input required type="text" class="form-control" id="name" name="name" placeholder="Your Name" value=""/>
                                        <label for="name">Your Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">  
                                    <div class="form-floating">
                                        <input required type="text" class="form-control" id="address" name="address" placeholder="Your Address" value=""/>
                                        <label for="address">Your Address</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input required type="number" class="form-control" id="phone_number" name="phone_number" placeholder="Your Phone Number" value=""/>
                                        <label for="phone_number">Phone Number</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating date" id="date3" data-target-input="nearest">
                                        <input required type="datetime-local" class="form-control datetimepicker-input" id="date" name="date" placeholder="Date & Time" data-target="#date3" data-toggle="datetimepicker" value="" />
                                        <label for="date">Date & Time</label>
                                    </div>
                                </div>
                                <div class="col-md-6">  
                                    <div class="form-floating">
                                        <input required type="email" class="form-control" id="email" name="email" placeholder="Your Email" value=""/>
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input required class="form-control form-control-input" type="number" name="no_of_people" value=""/>
                                        <label for="no_of_people">No Of People</label>
                                      </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary w-100 py-3" type="submit">Book Now</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div className='row-col-md-6 bg-dark h-auto d-inline-block w-50' style={{paddingTop: '80px', paddingBottom: '80px'}}> 
                <h5 class="section-title ff-secondary text-start text-primary fw-normal">Menu Order Request</h5>
                <div class="wow fadeInUp" data-wow-delay="0.2s">
                    <div className="container p-0">
                    <table className="table">
                        <thead>
                            <tr>
                        <th scope="col">#</th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                    {/* {orderedProducts.map((product, index) => (
                        <tr key={index}>
                            <th scope="row">{index + 1}</th>
                            <td>{product.product_name}</td>
                            <td>{product.price} php</td>
                        </tr>
                    ))} */}
                </tbody>
                </table>
                  </div>
                </div>
            </div>
        </div>
    );
}

export default OrderList;
