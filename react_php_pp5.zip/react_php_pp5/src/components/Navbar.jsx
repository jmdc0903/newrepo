import React, { useState, useEffect } from 'react';
function Navbar({}) {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    // Set loaded to true after the component has mounted
    setLoaded(true);
  }, []);
  return (
    <nav className={`container-fluid p-3 navbar navbar-expand-sm navbar-dark bg-dark sticky-top ${loaded ? 'loaded' : ''}`} id="navbar">
      <a href="/" className="navbar-brand p-0 m-0 ">
        <h1 className="text-primary"><i className="fa fa-utensils text-primary"></i> PHcuisine </h1>
      </a>
      <button className="navbar-toggler" title="title" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span className="fa fa-bars"></span>
      </button>
      <div className="collapse navbar-collapse" id="collapsibleNavbar">
        <div className="navbar-nav ms-auto py-0 pe-4">
          <a href="/" className="nav-item nav-link text-white" id="home-nav">Home</a>
          <a href="/about" className="nav-item nav-link text-white" id="about-nav">About</a>
          <a href="/services" className="nav-item nav-link text-white" id="services-nav">Services</a>
          <a href="/menu" className="nav-item nav-link text-white " id="menu-nav">Menu</a>
          <a href="#contact-us" className="nav-item nav-link text-white" id="contact-nav">Contact</a>
        </div>
        <a href="/orders" className="btn btn-primary py-2 px-3" id="orders-nav"><span><span className="badge badge-danger item_count">0</span><i class="fa fa-shopping-cart"></i>
          </span>Orders</a>
      </div>
    </nav>
  );
}
export default Navbar;
