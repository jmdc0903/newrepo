import React from "react";
import Layout from '../src/common/Layout/Layout';
// import ProductList from "./components/ProductList";

function App() {
  return (
  <div className="App">
     
      {/* <ProductList/> */}
      <Layout/>
    </div>
  );  
}
export default App;