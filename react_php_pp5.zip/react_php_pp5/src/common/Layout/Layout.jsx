
import Routes from "../../router/RouterApp";
import Header from "../../components/Navbar";
import Footer from "../../components/Footer";
import Carousel from "../../components/Carousel";
// import Testimonial from "../../components/Testimonial";

const Layout = () => {
    return (
        <>
        <Header />

            <Routes />

            <Carousel />

            {/* <Testimonial /> */}

        <Footer />
        </>
    );
    }
export default Layout;
