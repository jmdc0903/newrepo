
<?php
//fetch existing products
    function fetch_products($db) {
        try {
            $qProducts = "SELECT * FROM `db_pp5michael`.`tbl_products`";
            $eProducts = mysqli_query($db, $qProducts);
    
            if (mysqli_num_rows($eProducts) > 0) {
                while($row = mysqli_fetch_array($eProducts)) {
                    $data[] = [
                        'id' => $row['id'],
                        'category_id' => $row['category_id'],
                        'category_name' => $row['category_name'],
                        'name' => $row['name'],
                        'description' => $row['description'],
                        'price' => $row['price'],
                        'img_path' => $row['img_path'],
                        'status' => $row['status']
                    ];
                }
            } else {
                $products = [
                    'status' => 'ok',
                    'data' => [],
                ];
            }
            $aReturn = [
                'status' => 'ok',
                'data' => $data,
            ];
        } catch (Exception $e) {
            http_response_code(500);
            $aReturn = [
                'status' => 'error',
                'message' => $e->getMessage(),
                'code' => 500
            ];
        }
        return $aReturn;
    }
?>