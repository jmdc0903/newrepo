<?php
    $db = mysqli_connect("localhost", "root", "","db_pp5michael");
    if ($db == false) {
        echo "Failed to Connect to database!!!";
    }
?>

