<?php
    include "../includes/db_conn.php";
    if ($_POST) {

        $sFname = $_POST['txtFname'];
        $sLname = $_POST['txtLname'];
        $sEmail = $_POST['txtEmail'];
        $sPass = base64_encode($_POST['txtPass']);
        $sAccess = $_POST['txtAccess'];

        $qRegister = "INSERT INTO `db_michael`.`tbl_users`
            (`firstname`, `lastname`, `email`, `password`, `access_level`)
        VALUES
            ('".$sFname."', '".$sLname."', '".$sEmail."','".$sPass."', '".$sAccess."')
            ";
        $eRegister = mysqli_query($db, $qRegister);
        if ($eRegister == true) {
            echo "
                <script>
                    alert('Registration Successful');
                    location = 'login.php'
                </script>
            ";
        }

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>
    
    <div class="row mt-5">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="border p-5">
            <h1>Account Registration</h1>
            <form method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Firstname</label>
                    <input type="text" class="form-control" name="txtFname" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Lastname</label>
                    <input type="text" class="form-control" name="txtLname">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" class="form-control" name="txtEmail" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" name="txtPass">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Access Level</label>
                    <select name="txtAccess" class="form-control">
                        <option value="emp">Employee</option>
                        <option value="sup">Supervisor</option>
                        <option value="admin">Administrator</option>
                    </select>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">Register </button>
                </div>

                <p>
                    Already registered? <a href="login.php">Login Here</a>
                </p>
            </form>
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</html>