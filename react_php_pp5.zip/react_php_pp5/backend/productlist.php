<?php
include "db_conn.php";
header('Access-Control-Allow-Origin: *');
function fetch_all($db) {
// header('Content-Type: application/json');
$qProducts = "SELECT * FROM `db_pp5michael`.`tbl_products`"; // Adjust table name if needed
$eProducts = mysqli_query($db, $qProducts);



if (mysqli_num_rows($eProducts) > 0) {
    while($row = mysqli_fetch_array($eProducts)) {
        $data[] = [
            'id' => $row['id'],
            'category_id' => $row['category_id'],
            'category_name' => $row['category_name'],
            'product_name' => $row['product_name'],
            'description' => $row['description'],
            'price' => $row['price'],
            'img_path' => $row['img_path']
        ];
    }
}
echo json_encode($data);
}

fetch_all($db)
?>
